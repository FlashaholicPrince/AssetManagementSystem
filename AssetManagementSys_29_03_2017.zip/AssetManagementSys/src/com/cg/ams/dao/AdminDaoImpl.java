package com.cg.ams.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.cg.ams.bean.Asset;
import com.cg.ams.bean.AssetAllocation;
import com.cg.ams.bean.Request;
import com.cg.ams.exception.*;
import com.cg.ams.util.*;
import com.cg.ams.logger.*;



public class AdminDaoImpl implements AdminDao {

	Connection connection;
	PreparedStatement pstmt;
	static Logger  mylogger=DaoLogger.mylogger;
	public AdminDaoImpl()
	{
		try {
			connection = DBUtil.getConnect();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public boolean addAsset(Asset asset) throws AdminException  {
		
		boolean flag= false;
		int assetId=getId();
		String sql = "INSERT INTO asset VALUES(?,?,?,?,?)";
		
		try {
			
			 pstmt = connection.prepareStatement(sql);
			pstmt.setInt(1, assetId);
			pstmt.setString(2,asset.getAssetName());
			pstmt.setString(3,asset.getAssetDes());
			pstmt.setInt(4, asset.getAssetQuantity());
			pstmt.setString(5, asset.getAssetStatus());
			int row = pstmt.executeUpdate();
			if(row>0)
			{
				flag=true;
				mylogger.info("asset added with asset id="+assetId);
			}
			else
				mylogger.error("no record available");
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new AdminException("Asset already present");
		}
		
		return flag;
	}

	private int getId() throws AdminException {
		
		int aId=0;
		String qry="SELECT ASSET_ID_SEQ.NEXTVAL from dual";
		PreparedStatement pstmt;
		try {
			pstmt = connection.prepareStatement(qry);
			ResultSet res=pstmt.executeQuery();
			if(res.next())
			{
				aId=res.getInt(1);
			}
			
			else
			{
				throw new AdminException("NO ASSET ID SEQUENCE");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			throw new AdminException("Unable To Get The Id From Our Records");
		}
		
		return aId;
	}

	@Override
	public boolean modifyAsset(Asset asset) throws AdminException {
		
		boolean flag=false;
		
		String qry="update asset set assetname=?,assetdes=?,quantity=?,status=? where assetid=?";

		try {
			PreparedStatement pstmt = connection.prepareStatement(qry);
			if(validateAssetId(asset.getAssetId(),asset.getAssetName()))
			{	
			pstmt.setString(1,asset.getAssetName());
			pstmt.setString(2,asset.getAssetDes());
			pstmt.setInt(3, asset.getAssetQuantity());
			pstmt.setString(4, asset.getAssetStatus());
			pstmt.setInt(5, asset.getAssetId());
			int row = pstmt.executeUpdate();
			if(row>0)
			{
			flag=true;
			mylogger.info("Assets modified successfully");
			}
			
			else
			{
				mylogger.error("Error while updating asset");

				throw new AdminException("Cannot update asset");
			}
			}
			
		}
		catch (SQLException e) 
		{
			
			throw new AdminException("Unable To Update Asset Reason : Unable To Update In Database");
		}
		
		return flag;
		//return false;
	}

	private boolean validateAssetId(int aId,String aName) throws AdminException {
		
		boolean flag=false;
		String qry="SELECT COUNT(*) FROM asset WHERE ASSETID=? AND ASSETNAME=?";
		try {
			pstmt=connection.prepareStatement(qry);
			pstmt.setInt(1, aId);
			pstmt.setString(2, aName);
			ResultSet res=pstmt.executeQuery();
			res.next();
			if(res.getInt(1)>0)
			{
				flag=true;
			}
			
			else
			{
				mylogger.error("can not fetch asset id and asset name");

				throw new AdminException("asset id and asset name not found");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new AdminException("Unable To Validate AssetId Due To Some Database Error");
		}
		
		return flag;
	}

	@Override
	public ArrayList<Request> viewRequest() {
		ArrayList<Request>list = new ArrayList<Request>();
		return list;
	}

	@Override
	public boolean acceptRequest(int reqId) throws AdminException 
	{
		
		boolean flag=false;
		String qry="update request set status='ALLOCATED' where reqId=?";
		try {
			PreparedStatement pstmt = connection.prepareStatement(qry);
			pstmt.setInt(1,reqId);
			int row = pstmt.executeUpdate();
			if(row>0)
			{
				flag=true;
				mylogger.info("Request is accepted");
			}
			
			else
			{
				mylogger.error("unable to accept request");

				throw new AdminException("Unable To Accept The Request");
			}
		}
		catch(SQLException e)
		{
			throw new AdminException("Unable To Accept The Request Due To Some Database Error");
		}
		return flag;
	}

	@Override
	public boolean rejectRequest(int reqId) throws AdminException {
		
		boolean flag=false;
		String qry="update request set status='REJECTED' where reqId=?";
		try {
			PreparedStatement pstmt = connection.prepareStatement(qry);
			pstmt.setInt(1,reqId);
			int row = pstmt.executeUpdate();
			if(row>0)
			{
				flag=true;
				mylogger.info("Request Rejected");
			}
			else
			{
				mylogger.error("Unable to reject the request");

				throw new AdminException("Not updated");
			}
		}
		catch(SQLException e)
		{
			throw new AdminException("Unable To Reject The Request Due To Some Database Error");
		}
		return flag;
	}

	@Override
	public HashMap<Integer, Request> viewAllRequest() throws AdminException {
		HashMap<Integer,Request>map = new HashMap<Integer,Request>();
		
		String sql = "SELECT * FROM Request WHERE STATUS='PENDING'";
		
		try {
			Statement stmt = connection.createStatement();
			ResultSet res = stmt.executeQuery(sql);
			
			while(res.next())
			{
				Request req = new Request();
				
				req.setReqId(res.getInt(1));
				req.setMgrNum(res.getInt(2));
				req.setEmpNo(res.getInt(3));
				req.setAssetId(res.getInt(4));
				req.setAssetQuantity(res.getInt(5));
				req.setStatus(res.getString(6));
				req.setReleaseDate(res.getDate(7));
				
				map.put(res.getInt(1),req);
				
			}
			
			if(map.size()==0)
			{
				mylogger.error("Unable to fetch records");

			throw new AdminException("No Results Found");
				
			}
			else
			{
				mylogger.info(map);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new AdminException("Unable To View Request Due To Some Database Error");
		}
		
		return map;
	}

	@Override
	public boolean acceptManagerRequest(int reqId) throws AdminException {
		boolean flag=false;
		
		Request req = new Request();
		
		int quantity=getQuantity(reqId);
		
		int assetId = getAssetId(reqId);
		try {
		if(updateQuantity(assetId,quantity))
		
		{
			
		String qry="update request set status='ACCEPTED' where REQID=?";
		
			PreparedStatement pstmt = connection.prepareStatement(qry);
			pstmt.setInt(1,reqId);
			int row = pstmt.executeUpdate();
			if(row>0)
			{
				
				AssetAllocation aa=selectRequest(reqId);
				insertAsset(aa);
				flag=true;
				
			}
			else
			{
				mylogger.error("unable to accept the status");

				throw new AdminException("Not updated");
			}
		}
		else
		{
			throw new AdminException("Sorry The Requested Number Of Assets Are Not Available");
		}
		}
		catch(SQLException e)
		{
			throw new AdminException("Unable To Accept The Request Due To Some Database Error");
		}
		return flag;
	}
	
	public int getAssetId(int reqId) throws AdminException
	{
		int assetId=0;
		String qry="SELECT assetId from request where REQID=?";
		PreparedStatement pstmt;
		try {
			pstmt = connection.prepareStatement(qry);
			pstmt.setInt(1,reqId);
			ResultSet res=pstmt.executeQuery();
			if(res.next())
			{
				assetId=res.getInt(1);
			}
			else
			{
				throw new AdminException("No such assetid exists");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			throw new AdminException("Unable To Get The Unique Id From The Database");
		}
		
		return assetId;
	}

	public AssetAllocation selectRequest(int reqId) throws AdminException
	{
		String qry="SELECT ASSETID,EMPNO,RELEASE_DATE FROM REQUEST WHERE REQID=?";
		
		AssetAllocation aa = new AssetAllocation();
		try {
			pstmt=connection.prepareStatement(qry);
			pstmt.setInt(1,reqId);
			ResultSet res = pstmt.executeQuery();
			
			while(res.next())
			{
				aa.setAssetId(res.getInt(1));
				aa.setEmpNo(res.getInt(2));
				aa.setReleaseDate(res.getDate(3));
				//insertAsset(reqId,aa);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new AdminException("SQL EXCEPTION ");
		}
		return aa;
	}
	
	private void insertAsset(AssetAllocation aa) throws AdminException {
		
		String qry = "INSERT INTO ASSET_ALLOCATION VALUES(?,?,?,SYSDATE,?)";
		
		{
			try {
				pstmt = connection.prepareStatement(qry);
				int aId=getAllocationId();
				pstmt.setInt(1, aId);
				pstmt.setInt(2,aa.getAssetId());
				pstmt.setInt(3,aa.getEmpNo());
				pstmt.setDate(4,aa.getReleaseDate());
				pstmt.executeUpdate();
				
		
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new AdminException("Unable To Insert The Asset Into The Database");
			}
		}
	}
		
		private int getAllocationId() throws AdminException {
			
			int aId=0;
			String qry="SELECT ALLOT_ID_SEQ.nextval from dual";
			PreparedStatement pstmt;
			try {
				pstmt = connection.prepareStatement(qry);
				ResultSet res=pstmt.executeQuery();
				if(res.next())
				{
					aId=res.getInt(1);
				}
				
				else
				{
					throw new AdminException("No such allocationid");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				
				e.printStackTrace();
			}
			
			return aId;
			
			
		}
		
	@Override
	public boolean rejectManagerRequest(int reqId) throws AdminException {
		
		boolean flag=false;
		
		Request req = new Request();
		String qry="update request set status='Rejected' where REQID=?";
		try {
			PreparedStatement pstmt = connection.prepareStatement(qry);
			pstmt.setInt(1,reqId);
			int row = pstmt.executeUpdate();
		
			if(row>0)
			{
				flag=true;
				mylogger.info("Request Rejected");
				
			}
			
			else
			{
				mylogger.error("unable to update request");

				throw new AdminException("Not updated");
			}
		}
		catch(SQLException e)
		{
			throw new AdminException("Unable To Reject Request Because Of Database Error");
		}
		return flag;
	}

	@Override
	public boolean validateAdmin(String userid, String pwd, String usertype) throws AdminException {
		boolean flag = false;
	
		
		String sql="select count(*) from USER_MASTER where USERID=? and USERPASSWORD=? AND USERTYPE=?";
	
		
		try {
			
			PreparedStatement pstat = connection.prepareStatement(sql);
			pstat.setString(1, userid);
			pstat.setString(2, pwd);
			pstat.setString(3, usertype);
			ResultSet rset = pstat.executeQuery();
			rset.next();
			if(rset.getInt(1)==1)
			{
				flag = true;
				
			}
			else 
			{
				mylogger.error("admin is not valid");
				throw new AdminException("not valid admin");
			}
		} 
		
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new AdminException("Unable To Validate Admin Due To Database Error ");
		}
		return flag;
	}

	

	@Override
	public boolean validateAssetId(int assetId) throws AdminException {
		
		boolean flag = false;
		String qry = "SELECT COUNT(*) FROM asset WHERE ASSETID=?";
		try {
			pstmt=connection.prepareStatement(qry);
			pstmt.setInt(1, assetId);
			ResultSet res=pstmt.executeQuery();
			res.next();
			if(res.getInt(1)>0)
			{
				flag=true;
			}
			else
			{
				mylogger.error("can not fetch record");

				throw new AdminException("No assetid in asset");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new AdminException("Asset already present");
		}
		return flag;
	}
	
	@Override
	public Asset getAssetDetails(int assetId) throws AdminException
	{
		Asset asset=new Asset();
		String qry="SELECT * FROM ASSET WHERE ASSETID=?";
		try
		{
			pstmt=connection.prepareStatement(qry);
			pstmt.setInt(1, assetId);
			ResultSet res=pstmt.executeQuery();
			while(res.next())
			{
				asset.setAssetId(res.getInt(1));
				asset.setAssetName(res.getString(2));
				asset.setAssetDes(res.getString(3));
				asset.setAssetQuantity(res.getInt(4));
				asset.setAssetStatus(res.getString(5));
			}
		}
		catch(SQLException e)
		{
			throw new AdminException("Unable To Get The Available Asset Details");
		}
		
		return asset;
		
	}
	private int getQuantity(int reqId) throws AdminException {
		
			
		int quantity=0;
		String qry = "SELECT quantity FROM request WHERE REQID=?";
		try {
				PreparedStatement pstmt = connection.prepareStatement(qry);
				pstmt.setInt(1, reqId);
				ResultSet res = pstmt.executeQuery();
				while(res.next())
				{
					quantity=res.getInt(1);
				}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new AdminException("SQL EXCEPTION ");
		}
		
			return quantity;
	}
	@Override
	public HashMap<Integer, Asset> viewAssets() throws AdminException {
		
		
		HashMap<Integer,Asset> map = new HashMap<Integer,Asset>();
		
		String qry="SELECT * FROM ASSET";
		
		try
		{
			pstmt=connection.prepareStatement(qry);
			ResultSet res=pstmt.executeQuery();
			
			while(res.next())
			{
				
				Asset obj1=new Asset();
				obj1.setAssetId(res.getInt(1));
				obj1.setAssetName(res.getString(2));
				obj1.setAssetDes(res.getString(3));
				obj1.setAssetQuantity(res.getInt(4));
				obj1.setAssetStatus(res.getString(5));
				map.put(res.getInt(1), obj1);//add to list all these above fields
			
			}
			if(map.size()==0)
			{
				mylogger.error("no record available");

				throw new AdminException(" not Available!");
			}
			else
			{
				mylogger.info(map);
			}
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			throw new AdminException("SQL EXCEPTION");
		}
		
		
		
		return map;
	}

		private boolean updateQuantity(int aId,int quantity) throws AdminException {
		
			boolean flag = false;
			
			String qry = "UPDATE asset SET quantity=quantity=? WHERE ASSETID=? AND QUANTITY>=?";
			{
				try {
						PreparedStatement pstmt = connection.prepareStatement(qry);
						pstmt.setInt(1,quantity);
						pstmt.setInt(2,aId);
						pstmt.setInt(3, quantity);
						int row = pstmt.executeUpdate();
						if(row>0)
						{
							flag=true;
							mylogger.info("Quantity is updated");
						
						}
						
						else
						{
							mylogger.error("unable to update asset quantity");
							//throw new AdminException("Quantity is not available");
						}
					}
				catch(SQLException e)
				{
					throw new AdminException("Unable To Update The Quantity Due To Database Error");
				}
				return flag;
			}		
	}
}




