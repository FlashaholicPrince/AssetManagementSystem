package com.cg.ams.controller;
import java.io.IOException;
import java.sql.Date;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.cg.ams.bean.*;
import com.cg.ams.service.*;
import com.cg.ams.exception.ManagerException;


/**
 * Servlet implementation class ManagerController
 */
@WebServlet("/ManagerController")
public class ManagerController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	ManagerService service;
    /**
     * Default constructor. 
     */
    public ManagerController() {
        // TODO Auto-generated constructor stub
    	super();
    	service = new ManagerServiceI();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(false);
		String userId1=(String) session.getAttribute("userid");
		int uid = Integer.parseInt(userId1);
		String para = request.getParameter("action");
		session.setAttribute("managerName","manager");
		
		if("raiseRequest".equalsIgnoreCase(para))
		{
			
			RequestDispatcher dispatcher = 
			request.getRequestDispatcher("/managerpages/requestForm.jsp");
			dispatcher.forward(request, response);
		
		}
		else if("delete".equalsIgnoreCase(para))
		{
			String key = request.getParameter("key");
			Integer userId=(Integer) session.getAttribute("userId");
			int key1 = Integer.parseInt(key);
			try {
				boolean flag = service.deleteRequest(key1);
				if(flag)
				{
					
					HashMap<Integer,Request>map=service.viewStatus(userId);
					session.setAttribute("records", map);
					RequestDispatcher dispatcher = 
					request.getRequestDispatcher("/managerpages/viewrequest.jsp");
					dispatcher.forward(request, response);
				}
			} 
			
			catch (ManagerException e) {
				// TODO Auto-generated catch block
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("/managerpages/Manager.jsp");
				dispatcher.forward(request, response);
			}			
			
		}
		else if("Managerhome".equals(para))
		{
			request.getAttribute("userId");
			RequestDispatcher dispatcher=
					request.getRequestDispatcher("/managerpages/Manager.jsp");
			dispatcher.forward(request, response);
			
		}
		else if("viewAssets".equalsIgnoreCase(para))
		{
				
				try {
					HashMap<Integer,Asset>map=service.viewAssets();
					session.setAttribute("assets", map);
					RequestDispatcher dispatcher = 
					request.getRequestDispatcher("/managerpages/viewAssets.jsp");
					dispatcher.forward(request, response);
						
				}
				catch (ManagerException e) {
					// TODO Auto-generated catch block
					RequestDispatcher dispatcher=
							request.getRequestDispatcher("/managerpages/Manager.jsp");
					dispatcher.forward(request, response);
				}
		}
	
		else if("request".equalsIgnoreCase(para))
		{
			try {
				
				String userid2=(String) session.getAttribute("userid");
				int uid2 = Integer.parseInt(userid2);
				int mgr=service.getManagerNumber(uid2);
				ArrayList<Integer> list1=service.getEmployees(mgr);
				String key = request.getParameter("key");
				int key2 = Integer.parseInt(key);
				String assetName = request.getParameter("assetName");
				session.setAttribute("mgr", mgr);
				session.setAttribute("assetId", key2);
				session.setAttribute("assetName",assetName);
					RequestDispatcher dispatcher = 
					request.getRequestDispatcher("/managerpages/RaiseRequestForm.jsp");
					request.setAttribute("empList", list1);
					session.setAttribute("empList", list1);
				dispatcher.forward(request, response);
				} 
			catch (ManagerException e) {
				// TODO Auto-generated catch block
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("/managerpages/Manager.jsp");
				dispatcher.forward(request, response);
			}
			
		}

		else if("viewStatus".equalsIgnoreCase(para))
		{
			try {
				int userId=Integer.parseInt(request.getParameter("userId"));
				session.setAttribute("userId",userId);
				HashMap<Integer,Request>map=service.viewStatus(userId);
				session.setAttribute("records", map);
				RequestDispatcher dispatcher = 
				request.getRequestDispatcher("/managerpages/viewrequest.jsp");
				dispatcher.forward(request, response);
					
			}
			
			
			catch (ManagerException e) {
				// TODO Auto-generated catch block
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("/managerpages/Manager.jsp");
				dispatcher.forward(request, response);
			}
			
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String para = request.getParameter("action");
		String userid=(String) request.getAttribute("userId");
		if("ManagerLogin".equals(para))
		{
			HttpSession session = request.getSession(true);
			session.setAttribute("userid", userid);
			RequestDispatcher dispatcher=
					request.getRequestDispatcher("/managerpages/Manager.jsp");
			dispatcher.forward(request, response);
		}
		else if("fillForm".equalsIgnoreCase(para))
		{
			boolean flag=false;
			HttpSession session = request.getSession(false);
			String mgrNum = request.getParameter("mgrNum");
			String assetId = request.getParameter("assetId");
			String quantity = request.getParameter("quantity");
			String rDate = request.getParameter("rDate");
			LocalDate rrDate = LocalDate.parse(rDate);
			Date sqlDate =Date.valueOf(rrDate);
			String empNo = request.getParameter("empNo");
			int empNum =Integer.parseInt(empNo);
			String userId1=(String) session.getAttribute("userid");
			int uid = Integer.parseInt(userId1);
			
			Request req = new Request();
			
			req.setMgrNum(Integer.parseInt(mgrNum));
			req.setAssetId(Integer.parseInt(assetId));
			req.setAssetQuantity(Integer.parseInt(quantity));
			req.setStatus("PENDING");
			req.setReleaseDate(sqlDate);
			req.setEmpNo(empNum);
			try 
			{
				flag = service.insertFormDetails(req);
				
				if(flag)
				{
				session.setAttribute("formEntries", req);
				RequestDispatcher dispatcher = 
				request.getRequestDispatcher("/managerpages/viewAssets.jsp");
				dispatcher.forward(request, response);
				}
			}
			catch (ManagerException e) {
				// TODO Auto-generated catch block
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("/managerpages/Manager.jsp");
				dispatcher.forward(request, response);
			}
		}

	}

}
