package com.cg.ams.service;

import java.util.ArrayList;
import java.util.HashMap;
import com.cg.ams.bean.*;
import com.cg.ams.exception.*;

public interface ManagerService {
	
	public boolean insertFormDetails(Request req) throws ManagerException;
	//public ArrayList<Request> viewStatus(int userId) throws ManagerException;
	public HashMap<Integer, Request> viewStatus(int userId) throws ManagerException;
	public boolean deleteRequest(int key1) throws ManagerException;
	public HashMap<Integer, Asset> viewAssets() throws ManagerException;
	public boolean validateManager(String userid, String pwd, String usertype)throws ManagerException;
	int getManagerNumber(int userId) throws ManagerException;
	ArrayList<Integer> getEmployees(int mgrNo) throws ManagerException;

}
