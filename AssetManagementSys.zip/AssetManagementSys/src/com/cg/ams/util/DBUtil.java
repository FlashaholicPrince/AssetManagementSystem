/*package com.cg.project.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBUtil {
static InitialContext context;
	
	static DataSource datasource;
	static Connection connection;
	
	static
	{
		try {
			context=new InitialContext();
			
			datasource = (DataSource) context.lookup("java:/jdbc/TestDS");
		} 
		
		catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static Connection getConnect()
	{
		try {
			connection = datasource.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}
	
}
*/
package com.cg.ams.util;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;

public class DBUtil {
		static Connection con;
		static Properties prop;
		
		static
		{
			prop=new Properties();
			try{
			prop.load(new FileInputStream("C:/Users/Tonystark/Desktop/Module/Project/AssetManagementSys/WebContent/Propertyfiles"));
			String driver = prop.getProperty("driver");
			String url = prop.getProperty("url");
			String password = prop.getProperty("password");
			String username = prop.getProperty("username");
			Class.forName(driver);
			con = DriverManager.getConnection(url,username,password);
		}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
	}
		public static Connection getConnect()
		{
			return con;
		}
	}