package com.cg.ams.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.cg.ams.exception.*;

import com.cg.ams.service.*;


 
@WebFilter(filterName = "AuthFilter", urlPatterns = { "/AdminController","/UserController","/ManagerController"})	
	 public class LoginFilter implements Filter {
	
AdminService adminService;
ManagerService managerService;
	
    public LoginFilter() {
        // TODO Auto-generated constructor stub
    	adminService=new AdminServiceImpl();
    	managerService = new ManagerServiceI();
    }
		 
		 
		String userid, password;

		/*
		 * Here the annotation @WebInitParam is used with name and value pair
		 * specifying username and password used for authentication. These
		 * parameters could be retrieved in init-method of filter. Observe that URL
		 * Pattern attribute is mapped to HelloServlet, that means before request
		 * goes to HelloServlet it would pass through AuthFilter
		 */
		public void destroy() {
			// TODO Auto-generated method stub
		}

		/**
		 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
		 */
		public void doFilter(ServletRequest request, ServletResponse response,
				FilterChain chain) throws IOException, ServletException {

			PrintWriter printwriter = response.getWriter();
			HttpServletRequest req = (HttpServletRequest) request;
			
			String para = request.getParameter("action");
			HttpSession session = req.getSession();

			// These credentials obtained from login.html
			String userid = request.getParameter("id");
			String pwd = request.getParameter("pwd");
			String usertype= request.getParameter("usertype");
			
			
			
			if("admin".equalsIgnoreCase(usertype))
			{
			boolean flag;
			
			try {
				flag = adminService.validateAdmin(userid,pwd,usertype);
				if(flag)
				{
					session = req.getSession(false);
					chain.doFilter(request,response);
				}
			
			} 
			
			catch (AdminException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				request.setAttribute("error", e.getMessage());
				RequestDispatcher dispatcher= request.getRequestDispatcher("index.jsp");
				
				dispatcher.forward(request, response);
			printwriter.println("Invalid usser credentials, cannot enter inside::: Invalid user name given is:::"
					+ userid);
		
			}
		
			}
			
			else if("manager".equalsIgnoreCase(usertype))
				
			{
				boolean flag;

				try
				{
				flag =managerService.validateManager(userid,pwd,usertype);
					if(flag)
					{
						session = req.getSession(false);
						chain.doFilter(request,response);
					}
			}
			
			catch (ManagerException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				request.setAttribute("error", e.getMessage());
				RequestDispatcher dispatcher= request.getRequestDispatcher("index.jsp");
				
				dispatcher.forward(request, response);
			printwriter.println("Invalid usser credentials, cannot enter inside::: Invalid user name given is:::"
					+ userid);
		
			}
			}
			
			else if("viewForModify".equals(para))
				
			{
				
				if(session.isNew()==false)
				{
					
					chain.doFilter(request, response);
				}
				else
				{
					RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
					dispatcher.forward(request, response);
				}
				
			}
				else if("addForm".equals(para))
				{
					
					if(session.isNew()==false)
					{
						
						chain.doFilter(request, response);
					}
					else
					{
						RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
						dispatcher.forward(request, response);
					}
				}
			
				else if("modify".equals(para))
				{
					
					if(session.isNew()==false)
					{
						
						chain.doFilter(request, response);
					}
					else
					{
						RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
						dispatcher.forward(request, response);
					}
				}
				else if("Adminhome".equals(para))
				{
					if(session.isNew()==false)
					{
						
						chain.doFilter(request, response);
					}
					else
					{
						RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
						dispatcher.forward(request, response);
					}
					
				}
				else if("Managerhome".equals(para))
				{
					if(session.isNew()==false)
					{
						
						chain.doFilter(request, response);
					}
					else
					{
						RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
						dispatcher.forward(request, response);
					}
					
				}
				
				else if("viewRequest".equals(para))
				{
					if(session.isNew()==false)
					{
						
						chain.doFilter(request, response);
					}
					else
					{
						RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
						dispatcher.forward(request, response);
					}
					
				}
			
				else if("view".equalsIgnoreCase(para))
				{

					if(session.isNew()==false)
					{
						
						chain.doFilter(request, response);
					}
					else
					{
						RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
						dispatcher.forward(request, response);
					}
					
				}
			
				else if("accept".equalsIgnoreCase(para))
				{
					if(session.isNew()==false)
					{
						
						chain.doFilter(request, response);
					}
					else
					{
						RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
						dispatcher.forward(request, response);
					}
					
				}
			
				else if("reject".equalsIgnoreCase(para))
				{
					
					if(session.isNew()==false)
					{
						
						chain.doFilter(request, response);
					}
					else
					{
						RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
						dispatcher.forward(request, response);
					}
				}
			
			if("AdminLogin".equals(para))
			{
				if(session.isNew()==false)
				{
					
					chain.doFilter(request, response);
				}
				else
				{
					RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
					dispatcher.forward(request, response);
				}
			}
			
			else if("add".equals(para))
			{
				
				if(session.isNew()==false)
				{
					
					chain.doFilter(request, response);
				}
				else
				{
					RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
					dispatcher.forward(request, response);
				}
			}
			
			else if("modify".equals(para))
			{
				if(session.isNew()==false)
				{
					
					chain.doFilter(request, response);
				}
				else
				{
					RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
					dispatcher.forward(request, response);
				}
			}
			
			
			else if("modifyForm".equals(para))
			{
				
				if(session.isNew()==false)
				{
					
					chain.doFilter(request, response);
				}
				else
				{
					RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
					dispatcher.forward(request, response);
				}
			}
			
			
			if("raiseRequest".equalsIgnoreCase(para))
			{
				if(session.isNew()==false)
				{
					
					chain.doFilter(request, response);
				}
				else
				{
					RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
					dispatcher.forward(request, response);
				}
			}
			
			else if("delete".equalsIgnoreCase(para))
			{
				
				if(session.isNew()==false)
				{
					
					chain.doFilter(request, response);
				}
				else
				{
					RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
					dispatcher.forward(request, response);
				}
			}
			
			else if("viewAssets".equalsIgnoreCase(para))
			{
				
				if(session.isNew()==false)
				{
					
					chain.doFilter(request, response);
				}
				else
				{
					RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
					dispatcher.forward(request, response);
				}
			}
			
			else if("request".equalsIgnoreCase(para))
			{
				
				if(session.isNew()==false)
				{
					
					chain.doFilter(request, response);
				}
				else
				{
					RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
					dispatcher.forward(request, response);
				}
			}
			
			else if("viewStatus".equalsIgnoreCase(para))
			{
				
				if(session.isNew()==false)
				{
					
					chain.doFilter(request, response);
				}
				else
				{
					RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
					dispatcher.forward(request, response);
				}
			}
			
			if("ManagerLogin".equals(para))
			{
				if(session.isNew()==false)
				{
					
					chain.doFilter(request, response);
				}
				else
				{
					RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
					dispatcher.forward(request, response);
				}
			}
			
			else if("fillForm".equalsIgnoreCase(para))
			{
				if(session.isNew()==false)
				{
					
					chain.doFilter(request, response);
				}
				else
				{
					RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
					dispatcher.forward(request, response);
				}
				
			}
		}
			
		

		
		
		@Override
		public void init(FilterConfig arg0) throws ServletException {
			// TODO Auto-generated method stub
			
		}


	}

