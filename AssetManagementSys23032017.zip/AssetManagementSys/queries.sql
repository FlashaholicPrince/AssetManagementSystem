SELECT * FROM USER_MASTER;

select count(*) from USER_MASTER where USERID='Sur100' and USERPASSWORD='Sur@123' and usertype='Manager'

update USER_MASTER set usertype='ADMIN' where USERID='Roh100'
select * from asset

create sequence ASSET_ID_SEQ

SELECT ASSET_ID_SEQ.NEXTVAL from dual

SELECT * FROM USERs;