package com.cg.ams.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.cg.ams.bean.*;
import com.cg.ams.exception.AdminException;
import com.cg.ams.service.*;

/**
 * Servlet implementation class AdminController
 */
@WebServlet("/AdminController")
public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	AdminService service;
	
    public AdminController() {
        // TODO Auto-generated constructor stub
    	service=new AdminServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub]
		String para = request.getParameter("action");
		HttpSession session;
		if("AdminLogin".equals(para))
		{
			request.getAttribute("userId");
			session = request.getSession(true);
			RequestDispatcher dispatcher=
					request.getRequestDispatcher("/adminpages/Admin.jsp");
			dispatcher.forward(request, response);
		}
		else if("Adminhome".equals(para))
		{
			RequestDispatcher dispatcher=
					request.getRequestDispatcher("/adminpages/Admin.jsp");
			dispatcher.forward(request, response);
			
		}
		else if("viewForModify".equals(para))
		{

			try 
			{	
			
				HashMap<Integer,Asset>map=service.viewAssets();
				session = request.getSession(false);
				session.setAttribute("assets", map);
				RequestDispatcher dispatcher = 
						request.getRequestDispatcher("/adminpages/ViewAssetsForAdmin.jsp");
				dispatcher.forward(request, response);
					
			}
			catch (AdminException e) {
				// TODO Auto-generated catch block
				
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("/adminpages/Admin.jsp");
				dispatcher.forward(request, response);
			}
		}
		
		else if("addForm".equals(para))
		{
			RequestDispatcher dispatcher=
					request.getRequestDispatcher("/adminpages/Addassets.jsp");
			dispatcher.forward(request, response);
		}
	
		else if("modify".equals(para))
		{
			session = request.getSession(false);
			String key = request.getParameter("key");
			Asset asset = new Asset();
			
			int key2 = Integer.parseInt(key);
			try {
				asset=service.getAssetDetails(key2);
			
			session.setAttribute("assetId", key2);
			session.setAttribute("asset",asset);
			RequestDispatcher dispatcher = 
			request.getRequestDispatcher("/adminpages/modifyform.jsp");
			dispatcher.forward(request, response);
			} catch (AdminException e) {
				// TODO Auto-generated catch block
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("/adminpages/Admin.jsp");
				dispatcher.forward(request, response);
			}
		}
	
		else if("viewRequest".equals(para))//this is only for accepted requests
		{
			ArrayList<Request>list=new ArrayList<Request>();
			try {
				list=service.viewRequest();
			
			if(list.size()!=0)
			{
				request.setAttribute("list",list);
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("/adminpages/viewrequest.jsp");
				dispatcher.forward(request, response);
			
			}
			} catch (AdminException e) {
				// TODO Auto-generated catch block
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("/adminpages/Admin.jsp");
				dispatcher.forward(request, response);
			}
			
		}
		else if("view".equalsIgnoreCase(para))
		{
			HashMap<Integer,Request>map = new HashMap<Integer,Request>();
			try {
				map=service.viewAllRequest();
			
			if(map.size()!=0)
			 {
				 request.setAttribute("viewAllRequest",map);
				RequestDispatcher dispatcher = request.getRequestDispatcher("/adminpages/viewAllRequest.jsp");
				 dispatcher.forward(request, response);
			 }
			} catch (AdminException e) {
				// TODO Auto-generated catch block
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("/adminpages/Admin.jsp");
				dispatcher.forward(request, response);
			}
		}
		else if("accept".equalsIgnoreCase(para))
		{
			int key = Integer.parseInt(request.getParameter("key"));
			boolean flag;
			try {
				flag = service.acceptManagerRequest(key);
			

			HashMap<Integer,Request>map = new HashMap<Integer,Request>();
			map=service.viewAllRequest();
			
			if(flag)
			{
				 request.setAttribute("viewAllRequest",map);
                 RequestDispatcher dispatcher1= request.getRequestDispatcher("/adminpages/viewAllRequest.jsp");
					 dispatcher1.forward(request, response);
			}
			} catch (AdminException e) {
				// TODO Auto-generated catch block
				request.setAttribute("QuantityError", e.getMessage());
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("/adminpages/viewAllRequest.jsp");
				dispatcher.forward(request, response);
			}
		}
			
		
		else if("reject".equalsIgnoreCase(para))
		{
			int key = Integer.parseInt(request.getParameter("key"));
			boolean flag;
			try {
				flag = service.rejectManagerRequest(key);
			

			HashMap<Integer,Request>map = new HashMap<Integer,Request>();
			map=service.viewAllRequest();
			
			if(flag)
			{
				 request.setAttribute("viewAllRequest",map);
                 RequestDispatcher dispatcher1= request.getRequestDispatcher("/adminpages/viewAllRequest.jsp");
					 dispatcher1.forward(request, response);
			}
			} catch (AdminException e) {
				// TODO Auto-generated catch block
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("/adminpages/Admin.jsp");
				dispatcher.forward(request, response);
			}
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String para = request.getParameter("action");
		Asset asset=new Asset();
		
		if("AdminLogin".equals(para))
		{
			String userid=(String) request.getAttribute("userId");
			RequestDispatcher dispatcher=
					request.getRequestDispatcher("/adminpages/Admin.jsp");
			dispatcher.forward(request, response);
		}
	
		else if("add".equals(para))
		{
			String aName = request.getParameter("aName");
			String aDes = request.getParameter("aDes");
			int quantity=Integer.parseInt(request.getParameter("quan"));
			String status=request.getParameter("status");
			asset.setAssetName(aName);
			asset.setAssetDes(aDes);
			asset.setAssetQuantity(quantity);
			asset.setAssetStatus(status);
			boolean flag;
			try {
				flag = service.addAsset(asset);
				
			
			if(flag)
			{
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("/adminpages/Admin.jsp");
				dispatcher.forward(request, response);
			}
			} catch (AdminException e) {
				// TODO Auto-generated catch block
				request.setAttribute("error",e.getMessage());
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("/adminpages/Addassets.jsp");
				dispatcher.forward(request, response);
			}
			
		}

		else if("modify".equals(para))
		{
			int assetId=Integer.parseInt(request.getParameter("assetId"));	
			asset.setAssetId(assetId);
			request.setAttribute("assetId", assetId);
			boolean flag;
			try {
				flag = service.validateAssetId(assetId);
			
			if(flag)
			{
				request.setAttribute("assetId", assetId);
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("/adminpages/modifyform.jsp");
				dispatcher.forward(request, response);
			}
			} catch (AdminException e) {
				// TODO Auto-generated catch block
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("/adminpages/Admin.jsp");
				dispatcher.forward(request, response);
			}
			
		}

		else if("modifyForm".equals(para))
		{
			
			int assetId=Integer.parseInt(request.getParameter("aId"));
			String aName = request.getParameter("aName");
			String aDes = request.getParameter("aDes");
			int quantity=Integer.parseInt(request.getParameter("quan"));
			String status=request.getParameter("status");
			asset.setAssetId(assetId);
			asset.setAssetName(aName);
			asset.setAssetDes(aDes);
			asset.setAssetQuantity(quantity);
			asset.setAssetStatus(status);
			boolean flag;
			try {
				flag = service.modifyAsset(asset);
			
			if(flag)
			{
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("/adminpages/Admin.jsp");
				dispatcher.forward(request, response);
			}
			} catch (AdminException e) {
				// TODO Auto-generated catch block
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("/adminpages/Admin.jsp");
				dispatcher.forward(request, response);
			}
			
		}
		
	}

}
